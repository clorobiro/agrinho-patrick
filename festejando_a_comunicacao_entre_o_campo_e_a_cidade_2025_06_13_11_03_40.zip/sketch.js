let perguntas = [
  {
    pergunta: "O que significa sustentabilidade no campo?",
    opcoes: [
      "Usar todos os recursos rapidamente para lucro imediato",
      "Preservar os recursos naturais garantindo o futuro",
      "Substituir florestas por plantações extensas",
      "Produzir sem pensar nas futuras gerações"
    ],
    correta: 1
  },
  {
    pergunta: "Qual ação ajuda na preservação da água no meio rural?",
    opcoes: [
      "Lavar máquinas com mangueira constantemente",
      "Construir fossas sépticas e evitar poluição de rios",
      "Despejar lixo no rio",
      "Criar animais diretamente dentro dos rios"
    ],
    correta: 1
  },
  {
    pergunta: "Cidadania no campo envolve:",
    opcoes: [
      "Isolar-se da comunidade",
      "Ignorar leis ambientais",
      "Participar de decisões e respeitar o ambiente",
      "Não se preocupar com os vizinhos"
    ],
    correta: 2
  },
  {
    pergunta: "O que é agrotóxico?",
    opcoes: [
      "Produto usado para decorar plantações",
      "Substância usada para acelerar o crescimento natural",
      "Produto que combate pragas, mas exige cuidado ao usar",
      "Produto 100% seguro e inofensivo"
    ],
    correta: 2
  },
  {
    pergunta: "Qual é o papel da tecnologia no campo?",
    opcoes: [
      "Substituir o trabalhador rural completamente",
      "Reduzir produtividade e aumentar desperdício",
      "Facilitar processos, economizar recursos e aumentar produção",
      "Eliminar a tradição da agricultura familiar"
    ],
    correta: 2
  },
  {
    pergunta: "Que prática ajuda a manter o solo fértil?",
    opcoes: [
      "Desmatamento e queimadas constantes",
      "Rotação de culturas e adubação orgânica",
      "Lavar o solo com mangueira",
      "Cobrir o solo com cimento"
    ],
    correta: 1
  },
  {
    pergunta: "O que é reciclagem?",
    opcoes: [
      "Juntar lixo e jogar em terrenos baldios",
      "Transformar resíduos em novos produtos",
      "Enterrar plásticos para sumirem rápido",
      "Misturar todos os resíduos no mesmo saco"
    ],
    correta: 1
  },
  {
    pergunta: "Como podemos proteger a fauna no campo?",
    opcoes: [
      "Caçando para controle populacional",
      "Deixando lixo espalhado para os animais comerem",
      "Respeitando habitats naturais e evitando caça",
      "Criando animais exóticos soltos"
    ],
    correta: 2
  },
  {
    pergunta: "Qual dessas atitudes é exemplo de consumo consciente?",
    opcoes: [
      "Comprar sem necessidade",
      "Evitar desperdícios e escolher produtos sustentáveis",
      "Desperdiçar água à vontade",
      "Usar produtos com embalagens em excesso"
    ],
    correta: 1
  },
  {
    pergunta: "O que significa agricultura familiar?",
    opcoes: [
      "Grandes fazendas controladas por empresas estrangeiras",
      "Produção em pequena escala feita por famílias do campo",
      "Sistema onde tudo é mecanizado e sem trabalhadores",
      "Plantio feito apenas em hortas urbanas"
    ],
    correta: 1
  }
];

let perguntaAtual = 0;
let respostaSelecionada = -1;
let mostraResultado = false;
let pontuacao = 0;
let tentativas = 2;
let mensagem = "";

function setup() {
  createCanvas(700, 450);
  textAlign(LEFT, TOP);
  textSize(18);
}

function draw() {
background(255, 255, 0); // Amarelo forte
  if (perguntaAtual < perguntas.length) {
    mostrarPergunta();
  } else {
    mostrarPontuacaoFinal();
  }
}

function mostrarPergunta() {
  let q = perguntas[perguntaAtual];
  text(`Pergunta ${perguntaAtual + 1} de ${perguntas.length}:\n${q.pergunta}`, 20, 20);

  for (let i = 0; i < q.opcoes.length; i++) {
    let y = 100 + i * 40;
    fill(0);
    text(`${i + 1}. ${q.opcoes[i]}`, 40, y);

    if (mouseX > 20 && mouseX < 680 && mouseY > y && mouseY < y + 30) {
      fill(200);
      rect(20, y - 5, 660, 30);
      fill(0);
      text(`${i + 1}. ${q.opcoes[i]}`, 40, y);
    }
  }

  if (mostraResultado) {
    fill(mensagem.includes("✅") ? 'green' : 'red');
    text(mensagem, 20, 320);
    if (mensagem.includes("✅") || tentativas === 0) {
      text("Clique para continuar...", 20, 360);
    }
  }
}

function mousePressed() {
  if (mostraResultado && (mensagem.includes("✅") || tentativas === 0)) {
    mostraResultado = false;
    respostaSelecionada = -1;
    tentativas = 2;
    perguntaAtual++;
    mensagem = "";
  } else if (!mostraResultado) {
    let q = perguntas[perguntaAtual];
    for (let i = 0; i < q.opcoes.length; i++) {
      let y = 100 + i * 40;
      if (mouseX > 20 && mouseX < 680 && mouseY > y && mouseY < y + 30) {
        respostaSelecionada = i;
        if (i === q.correta) {
          pontuacao++;
          mensagem = "✅ Resposta correta! Parabéns!";
          mostraResultado = true;
        } else {
          tentativas--;
          if (tentativas > 0) {
            mensagem = `❌ Resposta incorreta. Você ainda tem ${tentativas} tentativa(s)!`;
            mostraResultado = true;
          } else {
            mensagem = "❌ Resposta incorreta. Você esgotou suas tentativas.";
            mostraResultado = true;
          }
        }
      }
    }
  }
}

function mostrarPontuacaoFinal() {
  fill(0);
  textSize(20);
  text(`🎉 Quiz finalizado! Você acertou ${pontuacao} de ${perguntas.length} perguntas.`, 20, 100);
  textSize(16);
  text("Clique com o botão direito na aba e atualize a página para tentar novamente.", 20, 160);
}
